package it.allumina.blescan.common;

public class Constants {
    public static final String TAG = "BLEScan";
    public static final String MONITOR_SERVICE_KILLED = "it.allumina.blescan.MONITOR_SERVICE_KILLED";
    public static final int TIMER_DELAY = 5000;
    public static final int TIMER_INTERVAL = 10000;

}
