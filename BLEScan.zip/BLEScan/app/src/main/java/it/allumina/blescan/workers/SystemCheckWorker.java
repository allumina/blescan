package it.allumina.blescan.workers;

public class SystemCheckWorker {
}
